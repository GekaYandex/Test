package com.step.geka;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parametrs {

    public static String getPhone(String[] mass){
        StringBuilder answer = new StringBuilder();
        for(String phone: mass) {
            answer.append("<li>" + phone + "</li>");
        }
        return answer.toString();
    }

    public static BigDecimal getSum(String[] mass) {
        BigDecimal masSum = new BigDecimal(0.0);
        Pattern pat=Pattern.compile("[\\s][0-9]+(.[0-9]+)?");
        for(String mas:mass){
            Matcher matcher=pat.matcher(mas);
            while (matcher.find()) {
                masSum =  masSum.add(BigDecimal.valueOf(Double.parseDouble(matcher.group())));
            }
        }
        return masSum;
    }
}
