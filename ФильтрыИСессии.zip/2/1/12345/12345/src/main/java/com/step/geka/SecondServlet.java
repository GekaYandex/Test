package com.step.geka;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(urlPatterns = {"/secondpage"})
public class SecondServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.getWriter().println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <title>Title</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<h1>Hello " +  req.getParameter("userName") + "!</h1>\n" +
                "<form action=\"/secondpage\" method=\"get\">\n" +
                "    <p> Make you order <br>\n" +
                "     <select id=\"phone\" name=\"phone\">\n" +
                "            <option value=\"iPhone6 600.5$\">iPhone6 600.5$</option>\n" +
                "            <option value=\"Lumia 950.55$\">Lumia 950.55$</option>\n" +
                "            <option value=\"Nexus 500.32$\">Nexus 500.32$</option>\n" +
                "            <option value=\"Galaxy 700.45$\">Galaxy 700.45$</option>\n" +
                "     </select><br>\n" +
                "    <input type=\"submit\"  value = \"Add\">\n" +
                "</form>\n" +
                "<form action=\"/thirdpage\" method=\"get\">\n" +
                "    <input type=\"submit\"  value = \"submit\">\n" +
                "</form>\n" +
                "</body>\n" +
                "</body>\n" +
                "</html>");
        req.getSession().setAttribute("name",req.getParameter("userName"));


    }
}
