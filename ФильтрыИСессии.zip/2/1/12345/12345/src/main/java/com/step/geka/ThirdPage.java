package com.step.geka;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@WebServlet(urlPatterns = {"/thirdpage"})
public class ThirdPage extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String[] phones = req.getParameterValues("phone");
        resp.getWriter().println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <title> </title>\n" +
                "    </head>\n" +
                "<body>\n" +
                "<p>Dear " + req.getSession().getAttribute("name") + ", your order:<br>\n" +
                 "<ol>" + Parametrs.getPhone(phones) +
                "</ol>\n" +
                "<p> Total: $" + Parametrs.getSum(phones) + ".\n" +
                "</body>\n" +
                "</html>");

    }



}

