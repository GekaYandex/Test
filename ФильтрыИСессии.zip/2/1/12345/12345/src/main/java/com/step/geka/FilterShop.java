package com.step.geka;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@WebFilter(urlPatterns = {"/secondpage"})
public class FilterShop implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;

        if (request.getSession().getAttribute("check") == null) { //проверяем есть ли в сессии наш флажок
            if (request.getParameter("check") == null) { //проверяем выбран ли наш флажок
                ServletContext servletContext = request.getServletContext();
                servletContext.getRequestDispatcher("/errorpage").forward(request, servletResponse);
            } else {

                request.getSession().setAttribute("check", request.getParameter("check")); //

            }

            filterChain.doFilter(request, servletResponse); //запускаем фильтр

        }
    }

    public FilterShop() {
        super();
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }
}
