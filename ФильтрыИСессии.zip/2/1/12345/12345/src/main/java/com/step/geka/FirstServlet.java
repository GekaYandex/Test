package com.step.geka;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(urlPatterns = {"/firstpage"})
public class FirstServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.getWriter().println("<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <title>Title</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "<form action=\"/secondpage\" method=\"get\">\n" +
                "    <h1> Welcome to online shop </h1>\n" +
                "    <input type=\"text\"  placeholder=\"enter yor name\" name = \"userName\" ><br>\n" +
                "    <input type=\"CheckBox\" name=\"check\"> I agree with the terms of service <br>\n" +
                "    <input type=\"submit\"  size=\"20px\" value = \"enter\">\n" +
                "    </form>\n" +
                "</body>\n" +
                "</html>");
    }
}
