//package com.company;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

import static java.lang.Integer.parseInt;

public class Server {
    private static Socket clientSocket;
    private static ServerSocket server;
    private static BufferedReader in;
    private static BufferedWriter out;

    public static void main(String[] args) {

        try {
            try {
                server = new ServerSocket(4006);
                System.out.println("Сервер запущен!");
                clientSocket = server.accept();
                try {
                    Arifmetic sum = new Arifmetic();
                    in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                    out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
                    out.flush();
                    boolean isConnected = true;
                    while (isConnected) {
                        String word1 = in.readLine();
                        //int a = parseInt(word1);
                        String word2 = in.readLine();
                        //int b = parseInt(word2);
                        String sign = in.readLine();

                        if (word1.equals("стоп") || word2.equals("стоп") || sign.equals("стоп")) {
                            out.write("The End!!! \n");
                            out.flush();
                            isConnected = false;
                        } else {
                            int res = sum.calc(parseInt(word1), parseInt(word2), sign);
                            out.write("Результат = " + res + "\n");
                            out.flush();
                        }
                    }
                } finally {
                    clientSocket.close();
                    in.close();
                    out.close();
                }
            } finally {
                System.out.println("Сервер закрыт!");
                server.close();
            }
        } catch (IOException e) {
            System.err.println(e);
        }
    }
}
