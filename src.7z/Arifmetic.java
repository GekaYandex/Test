public class Arifmetic {
    public int calc(int a, int b, String c) {
        int res = 0;
        switch (c) {
            case "+":
                res = a + b;
                break;
            case "-":
                res = a - b;
                break;
            case "*":
                res = a * b;
                break;
            case "/":
                if (b == 0) {
                    System.out.println("Делить на ноль нельзя");
                    break;
                } else {
                    res = a / b;
                    break;
                }
        }
        return res;
    }

}
