//package com.company;

import java.io.*;
import java.net.Socket;

public class Client {

    private static Socket clientSocket;
    private static BufferedReader reader;
    private static BufferedReader in;
    private static BufferedWriter out;

    public static void main(String[] args) {
        try {
            try {
                clientSocket = new Socket("localhost", 4006);
                reader = new BufferedReader(new InputStreamReader(System.in));
                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
                System.out.println("Калькулятор онлайн))))");

                boolean isConnected = true;

                while (isConnected) {
                    String firstNumber = reader.readLine();
                    out.write(firstNumber + "\n");
                    String secondNumber = reader.readLine();
                    out.write(secondNumber + "\n");
                    String sign = reader.readLine();
                    out.write(sign + "\n");
                    out.flush();
                    if (firstNumber.equals("стоп") || secondNumber.equals("стоп") || sign.equals("стоп")) {
                        System.out.println(in.readLine());
                        isConnected = false;

                    } else {
                        String res = in.readLine();
                        System.out.println(res);

                    }
                }
            } finally {
                System.out.println("Клиент был закрыт...");
                clientSocket.close();
                in.close();
                out.close();
            }
        } catch (IOException e) {
            System.err.println(e);
        }

    }

}

