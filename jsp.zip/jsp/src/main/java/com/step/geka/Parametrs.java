package com.step.geka;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parametrs {

    public static String getPhone(String[] mass){
        StringBuilder answer = new StringBuilder();
        for(String phone: mass) {
            answer.append("<li>" + phone + "</li>");
        }
        return answer.toString();
    }

    public static String getLine(String[] mass){
        StringBuilder answer = new StringBuilder();
        if (mass.length==0){
            answer.append("Make yor order");
        }
        else{
            answer.append("Yor have already chosen:");
            for(String phone: mass) {
                answer.append("<li>" + phone + "</li>");
            }
        }
        return answer.toString();
    }

    public static BigDecimal getSum(String[] mass) {
        BigDecimal masSum = new BigDecimal(0.0);
        Pattern pat=Pattern.compile("[\\s][0-9]+(.[0-9]+)?");
        for(String mas:mass){
            Matcher matcher=pat.matcher(mas);
            while (matcher.find()) {
                masSum =  masSum.add(BigDecimal.valueOf(Double.parseDouble(matcher.group())));
            }
        }
        return masSum;
    }

    public static <T> T[] append(T[] arr, T element)
    {
        if (element==null){
            return arr;
        }else {
            T[] array = Arrays.copyOf(arr, arr.length + 1);
            array[arr.length] = element;
            return array;
        }
    }
}
