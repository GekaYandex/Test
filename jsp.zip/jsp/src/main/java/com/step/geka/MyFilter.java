package com.step.geka;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@WebFilter(urlPatterns = {"/secondpage.jsp"})
public class MyFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;

        if (request.getSession().getAttribute("check") == null) { //проверяем есть ли в сессии наш флажок
            if (request.getParameter("check") == null) { //проверяем выбран ли наш флажок
                ServletContext servletContext = request.getServletContext();
                servletContext.getRequestDispatcher("/errorpage.jsp").forward(request, servletResponse);
                request.getSession().invalidate();
            } else {
                request.getSession().setAttribute("check", request.getParameter("check")); //
            }
        }


        if (request.getSession().getAttribute("name") == null) { //проверяем имя в сессии
            if (request.getParameter("name").isEmpty()) { //проверяем введено ли имя на странице
                ServletContext servletContext = request.getServletContext();
                servletContext.getRequestDispatcher("/errorpage.jsp").forward(request, servletResponse);
                request.getSession().invalidate();
            } else {
                request.getSession().setAttribute("name", request.getParameter("name"));
            }
        }

        filterChain.doFilter(request, servletResponse); //запускаем фильтр

    }

    public MyFilter() {
        super();
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void destroy() {

    }
}


